class Average
{
   public static void main(String[] args)
   {
      int a=2;
	  int b=7;
	  int c=17;
	  int z;
	  z=(a+b+c)/3;
	  System.out.print(z);
	 
   }
}