class Assign3
	{
	public static void main(String[] arg)
	{
		int a=50;
		int b=5;
		int c=a/b;
		System.out.println("a/b=" +c);
	 

	}
	}