class Rectangle
{
   public static void main(String[] args)
   {
      int l=2;
	  double b=5;
	  System.out.println("Area of Rectangle="+(l*b));
	  System.out.print("Parameter of Rectangle="+(2*(l+b)));
   }
}