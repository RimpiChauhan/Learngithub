class Parameter
{
   public static void main(String[] args)
   {
      int r=2;
	  double pi=3.14;
	  System.out.println("Area of circle"+(r*r*pi));
	  System.out.print("Parameter of circle"+(2*pi*r));
   }
}