class assign5
	{
	public static void main(String[] arg)
	{ 
	int x=20;
	int y=10;
	System.out.println("x+y="+(x+y));
	System.out.println("x-y="+(x-y));
	System.out.println("x*y="+(x*y));
	System.out.println("x/y="+(x/y));
	System.out.println("x%y="+(x%y));
	

	
	}}