class Assign2
	{
	public static void main(String[] arg)
	{
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
	 

	}
	}