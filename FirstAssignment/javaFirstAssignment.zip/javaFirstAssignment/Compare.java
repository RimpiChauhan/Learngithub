class Compare1
{
	public static void main(String[] arg)
	{
	 int a=6;
	 int b=7;
	 if(a>b)
	 {
	 System.out.print("a is greater than b");
	 
	 }
	 else
	 {
	 System.out.print("b is greater than a");
	 }
	}
}